@extends('layouts.app')

@section('content')
    <h1> Wecome to Index</h1>
@endsection