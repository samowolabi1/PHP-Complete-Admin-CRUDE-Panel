<?php $__env->startSection('content'); ?>

<section id="about">
        <div class="container">
          <div class="row about-container">
  
            <div class="col-lg-6 content order-lg-1 order-2">
              <h2 class="title">REGISTRATION FORM</h2>
              <p>
                With just our three simple steps, you can start to create your orders and get them delivered. 
              </p>
  
              <div class="icon-box wow fadeInUp">
                <div class="icon"><i class="fa fa-shopping-bag"></i></div>
                <h4 class="title"><a href="">Create a profile</a></h4>
                <p class="description">Click on register from the homepage to fill our simple form.</p>
              </div>
  
              <div class="icon-box wow fadeInUp" data-wow-delay="0.2s">
                <div class="icon"><i class="fa fa-photo"></i></div>
                <h4 class="title"><a href="">Place your orders</a></h4>
                <p class="description">Sign in to your account to select all kinds of product you would like to oreder for your customers with our simple cart. </p>
              </div>
  
              <div class="icon-box wow fadeInUp" data-wow-delay="0.4s">
                <div class="icon"><i class="fa fa-bar-chart"></i></div>
                <h4 class="title"><a href="">Confirm Orders</a></h4>
                <p class="description">Once you are done selecting the products for your customers, our simple app displays all products and ask for confirmation.</p>
              </div>
  
            </div>
  
            <div class="col-lg-6 background order-lg-2 order-1 wow fadeInRight"></div>
          </div>
  
        </div>
      </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>